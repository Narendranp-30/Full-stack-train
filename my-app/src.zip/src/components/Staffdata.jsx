import React, { useState } from 'react';

const staffDetails = [
    {
        name: "Alice",
        staffId: "STAFF001",
        subject: "Mathematics"
    },
    {
        name: "Bob",
        staffId: "STAFF002",
        subject: "Science"
    },
    {
        name: "Charlie",
        staffId: "STAFF003",
        subject: "English"
    }
];

const Staffdata = () => {
    const [staff, setStaff] = useState(staffDetails);

    const deleteStaff = (staffId) => {
        setStaff(staff.filter(member => member.staffId !== staffId));
    };

    return (
        <div className="container">
            <h2>Staff Details</h2>
            <ul className="responsive-table">
                <li className="table-header">
                    <div>Staff Name</div>
                    <div>Staff ID</div>
                    <div>Subject</div>
                    <div>Action</div>
                </li>
                {staff.map((member) => (
                    <li className="table-row" key={member.staffId}>
                        <div>{member.name}</div>
                        <div>{member.staffId}</div>
                        <div>{member.subject}</div>
                        <div>
                            <button onClick={() => deleteStaff(member.staffId)}>Delete</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Staffdata;
