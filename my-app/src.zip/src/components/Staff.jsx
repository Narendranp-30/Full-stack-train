import { useContext, useState } from "react";
import { StudentContext } from "../contexts/Student";
import './Staff.css'

function Staff(){
    const {rollno,mark1,mark2,mark3,Submit,roll1,mark11,mark21,mark31}=useContext(StudentContext)
   
    return(
        <>
        <h3>Student Details</h3>
        <form>
        <input type="text" value={rollno} onChange={roll1} placeholder="enter rollno"></input><br/>
        <input type="Number" value={mark1} onChange={mark11}  placeholder="enter number 2"></input><br/>
        <input type="Number" value={mark2} onChange={mark21} placeholder="enter number 2"></input><br/>
        <input type="Number" value={mark3} onChange={mark31} placeholder="enter number 2"></input><br/>
        <button className="btn" onClick={Submit}>Submit</button>
        </form>
        </>
    )
}

export default Staff;