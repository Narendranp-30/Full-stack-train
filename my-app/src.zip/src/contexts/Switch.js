import { createContext } from "react";

export const SwitchContext=createContext(null)