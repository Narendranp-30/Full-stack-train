import { createContext } from "react";
export const CountContext = createContext(null)

export const ThemeContext = createContext(null)