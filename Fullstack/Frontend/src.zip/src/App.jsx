import { useState,useEffect } from "react"
import './App.css'
import {ThemeContext,CountContext} from './contexts/theme.js'
import Counter from './components/Counter'
import Navbar from './components/Navbar'
import Products from "./components/Products.jsx"
import { Outlet } from "react-router-dom"
const App = () => {
  const [theme,setTheme] = useState("dark")
  const [count,setCount]=useState(0)
  const toggleTheme = () =>{
    setTheme(theme === 'dark' ? 'light' : 'dark')
    setCount(count+1)
  }
  useEffect(()=>{
    document.body.className = theme
  },[theme])
  return(
    <ThemeContext.Provider value={{theme:theme, toggleTheme:toggleTheme}}>
    <Navbar/>
    <Outlet/>
    </ThemeContext.Provider>
  )
}
export default App

